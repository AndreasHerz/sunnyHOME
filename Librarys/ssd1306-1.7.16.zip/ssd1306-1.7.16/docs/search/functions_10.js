var searchData=
[
  ['template_5fsetmode',['template_setMode',['../group___l_c_d___i_n_t_e_r_f_a_c_e___a_p_i.html#gacdd648ca24705e26f4a92119d2337def',1,'template_setMode(lcd_mode_t mode):&#160;oled_template.c'],['../group___l_c_d___i_n_t_e_r_f_a_c_e___a_p_i.html#gacdd648ca24705e26f4a92119d2337def',1,'template_setMode(lcd_mode_t mode):&#160;oled_template.c']]],
  ['template_5fwxh_5finit',['template_WxH_init',['../group___l_c_d___i_n_t_e_r_f_a_c_e___a_p_i.html#ga92d46e811087f0a41cd87db44d52a96a',1,'oled_template.c']]],
  ['template_5fwxh_5fspi_5finit',['template_WxH_spi_init',['../group___l_c_d___i_n_t_e_r_f_a_c_e___a_p_i.html#gaba9953651f572974e583813e72d4ed84',1,'oled_template.c']]],
  ['top',['top',['../class_nano_sprite.html#a23e66ae55f65b2986111649a03dd391a',1,'NanoSprite::top()'],['../class_nano_fixed_sprite.html#ac715529bb8c1eb2bd161adc8cfa0009d',1,'NanoFixedSprite::top()']]]
];
