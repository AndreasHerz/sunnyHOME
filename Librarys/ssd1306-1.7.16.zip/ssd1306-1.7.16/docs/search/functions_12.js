var searchData=
[
  ['vga_5f128x64_5fmono_5finit',['vga_128x64_mono_init',['../group___l_c_d___i_n_t_e_r_f_a_c_e___a_p_i.html#ga0c5a94022f25032231a7ba4abb7e20a4',1,'vga_monitor.c']]],
  ['vga_5f96x40_5f8colors_5finit',['vga_96x40_8colors_init',['../group___l_c_d___i_n_t_e_r_f_a_c_e___a_p_i.html#ga67d1256f7c32955b61b10c9413675612',1,'vga_96x40_8colors_init(void):&#160;vga_monitor.c'],['../group___l_c_d___i_n_t_e_r_f_a_c_e___a_p_i.html#ga67d1256f7c32955b61b10c9413675612',1,'vga_96x40_8colors_init(void):&#160;vga_monitor.c']]]
];
