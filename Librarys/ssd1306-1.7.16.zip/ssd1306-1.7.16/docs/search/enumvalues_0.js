var searchData=
[
  ['black',['BLACK',['../canvas_8h.html#gadf764cbdea00d65edcd07bb9953ad2b7af77fb67151d0c18d397069ad8c271ba3',1,'canvas.h']]]
];
